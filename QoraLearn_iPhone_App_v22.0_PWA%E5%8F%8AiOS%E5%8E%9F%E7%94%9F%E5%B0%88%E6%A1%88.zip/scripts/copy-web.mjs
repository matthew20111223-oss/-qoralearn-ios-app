import fs from 'node:fs';
import path from 'node:path';
fs.rmSync('www',{recursive:true,force:true});fs.mkdirSync('www',{recursive:true});
for(const f of ['index.html','admin.html','404.html','qoralearn-logo.png','manifest.webmanifest','sw.js','icons']){if(fs.existsSync(f))fs.cpSync(f,path.join('www',f),{recursive:true});}
console.log('QoraLearn web app copied to www/');
