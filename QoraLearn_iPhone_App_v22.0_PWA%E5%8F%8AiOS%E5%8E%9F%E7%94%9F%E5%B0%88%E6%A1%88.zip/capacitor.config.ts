import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.qoralearn.app',
  appName: 'QoraLearn',
  webDir: 'www',
  server: { androidScheme: 'https' },
  ios: { contentInset: 'automatic', backgroundColor: '#F7F6F0' }
};
export default config;
