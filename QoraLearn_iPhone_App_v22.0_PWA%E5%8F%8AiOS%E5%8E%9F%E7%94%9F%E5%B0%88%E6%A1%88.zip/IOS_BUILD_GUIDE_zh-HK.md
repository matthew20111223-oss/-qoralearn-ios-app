# QoraLearn iPhone App 建置指南

## 已包含
- PWA manifest、Service Worker、iOS 主畫面圖示及 standalone 顯示設定。
- iPhone safe-area / Dynamic Island 避讓、底部 App 導覽及「更多」互動式底部面板。
- Capacitor iOS wrapper 專案設定，沿用現有 Supabase / Gemini 網頁端功能。

## 先在 iPhone 安裝 PWA
1. 將本 ZIP 內網站檔案部署至 HTTPS 網域（例如 qoralearn.com）。
2. 用 iPhone Safari 開啟網站並登入。
3. 點分享 → 加入主畫面 → 開啟「以網頁 App 方式開啟」（若系統有顯示）。
4. 從主畫面圖示開啟 QoraLearn。

## 建置原生 iOS App
需要 macOS、Xcode、Node.js 及 Apple Developer 帳戶（測試安裝可先使用 Xcode 個人簽署；App Store 發布需符合 Apple 當時要求）。

```bash
npm install
npm run cap:add:ios
npm run cap:sync
npm run ios
```
在 Xcode 選擇你的 Team、Bundle Identifier `com.qoralearn.app`，連接 iPhone 後 Build / Run。正式上架前需補齊隱私權政策、App 隱私資料申報、權限說明、截圖及 Apple 審核要求。

## 裝置適配
- 普通 iPhone：單欄內容、固定底部五項導覽、底部「更多」功能面板。
- 大螢幕／可摺疊視窗：較寬時自動擴展版面；支援 CSS viewport segments 的裝置可使用雙區段版面。
- 注意：Apple 尚未正式確認名為「iPhone Duo」的型號。本版本按一般 iPhone、寬螢幕及可摺疊視窗能力作彈性適配，不假設特定未發布機型規格。

## 網絡及安全
Service Worker 只快取網站外殼與靜態檔案，不快取 Supabase Auth、REST 或 Edge Function 回應；登入、AI 批改、題庫同步仍需要網絡。不要將 service-role key 放進前端或 App 包內。
